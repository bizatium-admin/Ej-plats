<powershell>
# Function to write to a log file
function Write-Log {
  [CmdletBinding()]
  param(
    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string]$Message
  )
  [pscustomobject]@{
    Time    = (Get-Date -f g)
    Message = $Message
  } | Export-Csv -Path "c:\windows\temp\build.log" -Append -NoTypeInformation
}
Write-Log -Message "Userdata: Started"

# Rename instance
$InstanceName = "${hostname}"
If ($null -ne $InstanceName) {
  Write-Log -Message "EC2 Instance: Renaming to $InstanceName"
  Rename-Computer -NewName $InstanceName -Force -Restart
}
else {
  Write-Log -Message "EC2 Instance: skipping rename."
}

# Set, Check GTM timezone
$timezone = "GMT Standard Time"
if ((Get-TimeZone).id -ne $timezone) {
  Write-Log -Message "Timezone: needs updating to:" $timezone
  Set-TimeZone -Name "GMT Standard Time"
}
else {
  Write-Log -Message "TimeZone: already set, skipping"
}

# Expand D-Drive
$driveD = "D"
$MaxSize = (Get-PartitionSupportedSize -Drive $driveD).sizeMax
$MaxSizeGB = [math]::Round($MaxSize / 1024 / 1024 / 1024, 2)
Write-Log -Message "EBS Volume [Expand]: Max size is $MaxSizeGB GB"
if ((get-partition -driveletter $driveD).size -eq $MaxSize) {
  Write-Log -Message "EBS Volume [Expand]: Drive: $driveD is already set to max, skipping"
}
else {
  Resize-Partition -DriveLetter $driveD -Size $MaxSize
  Write-Log -Message "EBS Volume [Expand]: Resizing Drive $driveD to Max"
}

# Configure all raw disks to GPT and format to NTFS
# TODO: Allow label to be set via variable in terraform
$VoluneLabel = "Data"
if ((Get-Disk | Where-Object PartitionStyle -eq 'raw').count -eq 0) {
  Write-Log -Message "EBS Volume [Configure]: No raw disks found, skipping"
}
else {
  Write-Log -Message "EBS Volume [Configure]: Raw disks found, configuring"
  Stop-Service -Name ShellHWDetection
  Get-Disk | Where-Object PartitionStyle -eq 'raw' | Initialize-Disk -PartitionStyle GPT -PassThru | New-Partition -AssignDriveLetter -UseMaximumSize | Format-Volume -FileSystem NTFS -NewFileSystemLabel $VoluneLabel -Confirm:$false
  Start-Service -Name ShellHWDetection
  Write-Log -Message "EBS Volume [Configure]: Configured additional disks"
}

# ==== Domain join if required ===============================================
# if ((gwmi win32_computersystem).partofdomain -eq $false) {
#   Write-Log -Message "Domain Join: $InstanceName is not on the domain ${domain}, joining now."
#   $domain = "${domain}"
#   $path = "${domain_join_path}"
#   $bar = [System.Text.Encoding]::ASCII.GetString([System.Convert]::FromBase64String((Get-SSMParameter -Name nicc-tooling-secret -WithDecryption $true).Value))
#   $password = ConvertTo-SecureString ($bar.Trim()) -AsPlainText -Force
#   $cred = New-Object System.Management.Automation.PSCredential ("europe\svc.automation", $password)
#   Add-Computer -DomainName $domain -OUPath $path -Credential $cred -PassThru -Verbose -ErrorAction stop
#   Write-Log -Message "Domain Join: Restarting $InstanceName, domain policies will be appled."
#   Restart-Computer
# }
# else {
#   Write-Log -Message "Domain Join: $InstanceName is already in: ${domain} , skipping."
# }

Write-Log -Message "Userdata: Completed"
</powershell>
<persist>true</persist>