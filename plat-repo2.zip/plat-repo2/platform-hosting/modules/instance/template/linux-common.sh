#!/bin/bash
# Set the host name & Time
hostname ${hostname}
echo ${hostname} > /etc/hostname
timedatectl set-timezone Europe/London
yum update -y