##### NPS Servers (Network Policy Servers) in NLZ for SDWAN Radius | [NICC-2203](https://jira.build.easyjet.com/browse/NICC-2203) 

##### Manual Tweaks

```powershell
Install-WindowsFeature -Name npas -IncludeManagementTools
New-Item D:\NPSLogs -ItemType directory
```

##### Notes
- servers to be domain-joined and nps configured by the Networking team
- servers handed over 04/08/23