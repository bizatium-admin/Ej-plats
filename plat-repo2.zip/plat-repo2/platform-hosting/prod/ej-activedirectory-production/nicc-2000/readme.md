#### NLZ AD Servers and Bastions | [NICC-2000](https://jira.build.easyjet.com/browse/NICC-2000) | [ERF](https://easyjet.sharepoint.com/:x:/r/teams/DSP-CloudMigration/Shared%20Documents/General/AD%20Upgrade/Draft%20ERFs/NICC%20ERF_AWS%20AD_MAY%202023_prod.xlsx?d=w8d3990e71e4d437cb341638cebe65a8d&csf=1&web=1&e=2S0BsM) | AWS: ej-activedirectory-production
<br/>

#### Stack Notes
- 2 ad servers (1a, 1c)
- 6 bastion servers (3x1a, 3x1c)
- 2 securiry groups (1xad, 1xbas)
- servers are non-domained joined and non-cis harderned (hardning will be appled once on the new domain)
- temporary local account used by the project team is called: ad-admin, this is to be removed/disabled once domain & gpo's applied.
- 08/06/23 NICC-2076 to add 4 x tier 2 bastions


#### Manual Tweaks

```powershell
# create temp local admin account for the project team
$Password = Read-Host -AsSecureString
New-LocalUser "ad-admin" -Password $Password -PasswordNeverExpires:$true -FullName "ad-admin" -Description "NLZ AD Temp Local Admin Account"
Add-LocalGroupMember -Group "Administrators" -Member "ad-admin"
Get-LocalGroupMember -Group "Administrators"
```

```powershell  
# rename and disable the administrator account
Rename-LocalUser -Name "Administrator" -NewName "Use default ej admin name"     
Disable-LocalUser -Name "Use default ej admin name"     
```

```powershell
# set legalnoticecaption
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "legalnoticecaption" -Value "*** Warning ***"

#set legalnoticetext
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "legalnoticetext" -Value "This system is the property of easyJet Airline Company Limited and is intended only for the use of authorised employees and authorised 3rd party partners.  Any unauthorised access or use of this system is strictly prohibited and is deemed an intrusion and may be subject to criminal prosecution under the Computer Misuse Act 1990.   Access or use beyond specified and authorised actions without specific prior authorisation from easyJet Airline Company Limited is strictly prohibited. By accessing this system, the user acknowledges proper authorisation to use the system and the data accessed. The user also acknowledges that they will exercise due care in ensuring the security of confidential data is maintained at all times, and act in accordance with easyJets Information Security Policy published on our Intranet (https://easyjet.sharepoint.com/sites/DigitalSafetyHub/SitePages/Policies.aspx)."
```
