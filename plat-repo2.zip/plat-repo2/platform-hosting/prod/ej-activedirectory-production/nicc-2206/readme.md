#### Semperis DSP Instances | [NICC-2206](https://jira.build.easyjet.com/browse/NICC-2206) | [Sharepoint](https://easyjet.sharepoint.com/:f:/r/teams/NICC/Shared%20Documents/Platform%20Engineering/Projects?csf=1&web=1&e=836tMW) | July 2023

#### <u>Semperis DSP</u>
Semperis Directory Services Protector (DSP) is known for providing uninterrupted tracking of AD modifications and immediate rollback of unwanted changes, without having to mount backups or take DCs offline. It provides the capabilities you need to defend AD from cyberattacks, detects hidden changes, and alerts you to potential attacks in progress.
#### <u>Stack Notes</u>
- 6 instances in total for semperis dsp (directory services protector)
- all instances will be domain-joined to ezhost (carried out by project team)
- new sg created for inbound rules
- 1 instance now destroyed to redeploy as sql std using new pipeline (August 2023 - NICC-2175)

#### Updates
- 24/08/23 new instance now deployed as sql server 2019 std payg [D2ENPRODWPW010 / 10.112.33.167]
- 24/08/23 account permission granted for DBA's: GG_LZ_DBA_PU with PU/DBA/RO permission sets