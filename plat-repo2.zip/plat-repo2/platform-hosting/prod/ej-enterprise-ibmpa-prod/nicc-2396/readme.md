##### IBMPA Planning Analytics Secure Gateway Client | [NICC-2396](https://jira.build.easyjet.com/browse/NICC-2396) 
### https://conf.build.easyjet.com/display/TechFin/Planning+Analytics+-+IBM+Cloud+Solution
### https://easyjet.sharepoint.com/:f:/r/teams/NICC/Shared%20Documents/Platform%20Engineering/Projects?csf=1&web=1&e=heN06b

##### Manual Tweaks

```
```

##### Notes
- No resilience - a single server only for now - waiting on decision regarding Unit4 hosting direction. 
- There is no requirement from IBM for Secure Gateway to have additional storage, as no data will be stored on this instance. Default 30gb storage is sufficient.
- There is no requirement to be domain joined.
- No static “public” IP is needed - access (from IBM PA Cloud) is controlled by IBM via security token to connect, to create the gateway from PA Cloud Environment to the client, the client security token is required to establish the connection.
- No additional user access required (there's an existing PU group).  Longer term, this group is likely to contain the PA developers who will need access to the instance to renew the security token periodically. 
- There will be an additional standard firewall request once the gateway client is installed on the instance - to allow the gateway client server to talk out to the Internet to a specific PA cloud (IBM) Gateway server (see Network tab)".	